# Smart Campus Energy Optimization API

BUP CSE Fest 2026 Hackathon — Preliminary Round submission.

## Architecture

```
Energy Data + Operator Notes -> LLM Interpreter -> Guardrail Validator
                              -> Math Optimizer -> Final Response
```

| File                | Responsibility                                                        |
|---------------------|-------------------------------------------------------------------------|
| `main.py`           | FastAPI app, `/health` and `/optimize-energy` endpoints, orchestration |
| `models.py`         | Pydantic request/response schema (Sections 07 & 10)                    |
| `llm_interpreter.py`| Calls Claude to turn operator notes into raw structured directives     |
| `guardrails.py`     | Deterministic validation of LLM output (Section 08, safe failure)      |
| `optimizer.py`      | Builds and solves the 24-hour LP with PuLP (Sections 05.3 & 09)        |
| `test_offline.py`   | Offline sanity test of guardrails + optimizer (no API key needed)      |

## Setup

```bash
pip install -r requirements.txt
export ANTHROPIC_API_KEY=your_key_here   # required for live LLM interpretation
# optional: export ANTHROPIC_MODEL=claude-sonnet-5   (default)
```

## Run

```bash
uvicorn main:app --host 0.0.0.0 --port 8000
```

## Test

```bash
python3 test_offline.py          # guardrails + optimizer, no API key needed
curl http://localhost:8000/health
curl -X POST http://localhost:8000/optimize-energy \
     -H "Content-Type: application/json" -d @sample_request.json
```

## Notes on design choices

- **LLM output is never trusted directly.** `guardrails.py` re-checks every
  field (directive type, hour range/order/uniqueness, factor bounds, etc.)
  before anything reaches the optimizer. Malformed or missing entries are
  safely coerced to `no_op` instead of crashing the service (Section 08).
- **If the LLM call itself fails** (network/auth/parse error), `main.py`
  logs a warning and treats all notes as unresolved; the guardrail layer
  then fills them in as safe `no_op` entries so the service still returns
  a valid 200 response with a feasible schedule.
- **Directive combination rules:**
  - Multiple `solar_reduction` directives on the same hour multiply.
  - Multiple `minimum_battery_reserve` directives on the same hour take the max.
  - Multiple `max_grid_window` directives on the same hour take the min (tightest cap).
  - `no_charge_window` / `no_discharge_window` hours are unioned across notes.
- **Battery action output** (`charge` / `discharge` / `idle`) is derived
  from the *net* change in stored energy each hour, so the response never
  reports simultaneous charge and discharge in the same hour.
- Solved with PuLP's bundled CBC solver — no external solver install needed.
