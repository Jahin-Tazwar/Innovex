"""
Math Optimizer — builds and solves the 24-hour linear program that
minimizes total grid electricity cost, subject to the GridWise energy
rules (Section 09) and every applied operator directive (Section 05.3).
"""
from typing import List, Dict, Any
import pulp


class InfeasibleScenarioError(Exception):
    pass


def _apply_directives(
    hours_data: List[Dict[str, Any]],
    battery: Dict[str, Any],
    directives: List[Dict[str, Any]],
):
    """
    Reduces validated directives into per-hour deterministic parameters:
      - effective_solar[h]
      - reserve_floor[h]      (max of base minimum_energy_kwh and any active directive)
      - charge_allowed[h]     (False if a no_charge_window covers h)
      - discharge_allowed[h]  (False if a no_discharge_window covers h)
      - grid_cap[h]           (min of any active max_grid_window caps, else None)
    """
    n = 24
    effective_solar = [hours_data[h]["solar_kwh"] for h in range(n)]
    reserve_floor = [battery["minimum_energy_kwh"]] * n
    charge_allowed = [True] * n
    discharge_allowed = [True] * n
    grid_cap = [None] * n

    for d in directives:
        if not d.get("applies"):
            continue
        dtype = d["directive_type"]
        adj = d["structured_adjustment"]
        listed_hours = adj.get("hours", [])

        if dtype == "solar_reduction":
            factor = float(adj["factor"])
            for h in listed_hours:
                effective_solar[h] *= factor

        elif dtype == "minimum_battery_reserve":
            val = float(adj["minimum_energy_kwh"])
            for h in listed_hours:
                reserve_floor[h] = max(reserve_floor[h], val)

        elif dtype == "no_charge_window":
            for h in listed_hours:
                charge_allowed[h] = False

        elif dtype == "no_discharge_window":
            for h in listed_hours:
                discharge_allowed[h] = False

        elif dtype == "max_grid_window":
            cap = float(adj["max_grid_kwh"])
            for h in listed_hours:
                grid_cap[h] = cap if grid_cap[h] is None else min(grid_cap[h], cap)

    return effective_solar, reserve_floor, charge_allowed, discharge_allowed, grid_cap


def solve_schedule(
    hours_data: List[Dict[str, Any]],
    battery: Dict[str, Any],
    directives: List[Dict[str, Any]],
) -> Dict[str, Any]:
    n = 24
    demand = [hours_data[h]["demand_kwh"] for h in range(n)]
    tariff = [hours_data[h]["tariff_bdt_per_kwh"] for h in range(n)]
    capacity = battery["capacity_kwh"]
    initial_energy = battery["initial_energy_kwh"]
    max_charge_rate = battery["max_charge_kwh_per_hour"]
    max_discharge_rate = battery["max_discharge_kwh_per_hour"]

    effective_solar, reserve_floor, charge_allowed, discharge_allowed, grid_cap = _apply_directives(
        hours_data, battery, directives
    )

    prob = pulp.LpProblem("energy_schedule", pulp.LpMinimize)

    grid = [pulp.LpVariable(f"grid_{h}", lowBound=0) for h in range(n)]
    solar_used = [pulp.LpVariable(f"solar_used_{h}", lowBound=0) for h in range(n)]
    charge = [
        pulp.LpVariable(f"charge_{h}", lowBound=0, upBound=(max_charge_rate if charge_allowed[h] else 0))
        for h in range(n)
    ]
    discharge = [
        pulp.LpVariable(
            f"discharge_{h}", lowBound=0, upBound=(max_discharge_rate if discharge_allowed[h] else 0)
        )
        for h in range(n)
    ]
    battery_after = [pulp.LpVariable(f"batt_after_{h}", lowBound=0, upBound=capacity) for h in range(n)]

    # Objective: minimize total grid cost
    prob += pulp.lpSum(grid[h] * tariff[h] for h in range(n))

    for h in range(n):
        # Solar usage cannot exceed effective solar
        prob += solar_used[h] <= effective_solar[h]

        # Energy balance
        prev_energy = initial_energy if h == 0 else battery_after[h - 1]
        prob += battery_after[h] == prev_energy + charge[h] - discharge[h]
        prob += grid[h] + solar_used[h] + discharge[h] == demand[h] + charge[h]

        # Battery bounds (reserve floor, possibly raised by directive)
        prob += battery_after[h] >= reserve_floor[h]
        prob += battery_after[h] <= capacity

        # Grid cap directive
        if grid_cap[h] is not None:
            prob += grid[h] <= grid_cap[h]

    # End-of-day battery neutrality
    prob += battery_after[n - 1] == initial_energy

    status = prob.solve(pulp.PULP_CBC_CMD(msg=0))

    if pulp.LpStatus[status] != "Optimal":
        raise InfeasibleScenarioError(
            f"No feasible schedule found (solver status: {pulp.LpStatus[status]})"
        )

    hourly_plan = []
    prev_energy = initial_energy
    for h in range(n):
        c = max(0.0, pulp.value(charge[h]) or 0.0)
        d = max(0.0, pulp.value(discharge[h]) or 0.0)
        net = c - d

        if net > 1e-6:
            action, magnitude = "charge", net
        elif net < -1e-6:
            action, magnitude = "discharge", -net
        else:
            action, magnitude = "idle", 0.0

        energy_after = prev_energy + net
        prev_energy = energy_after

        hourly_plan.append(
            {
                "hour": h,
                "grid_kwh": round(max(0.0, pulp.value(grid[h]) or 0.0), 6),
                "solar_used_kwh": round(max(0.0, pulp.value(solar_used[h]) or 0.0), 6),
                "battery_action": action,
                "battery_kwh": round(magnitude, 6),
                "battery_energy_after_kwh": round(energy_after, 6),
            }
        )

    total_grid_kwh = round(sum(e["grid_kwh"] for e in hourly_plan), 6)
    total_cost_bdt = round(sum(e["grid_kwh"] * tariff[h] for h, e in enumerate(hourly_plan)), 6)
    peak_grid_kwh = round(max(e["grid_kwh"] for e in hourly_plan), 6)

    return {
        "hourly_plan": hourly_plan,
        "total_grid_kwh": total_grid_kwh,
        "total_cost_bdt": total_cost_bdt,
        "peak_grid_kwh": peak_grid_kwh,
    }
