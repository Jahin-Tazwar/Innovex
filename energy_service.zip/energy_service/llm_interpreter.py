"""
LLM Interpreter — converts natural-language operator notes into structured
directive JSON using the Anthropic Claude API.

Per Section 08: LLM output is UNTRUSTED until it passes the guardrail
validator in guardrails.py. This module only calls the model and parses
its raw JSON; it does not decide correctness.
"""
import json
import os
import re
from typing import List, Dict, Any

import anthropic

MODEL_NAME = os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-5")

SYSTEM_PROMPT = """You are an expert NLP parser for a Smart Campus Energy Optimization System.
Your task is to interpret 1 to 3 operator notes for a 24-hour energy planning scenario (hours 0 to 23).

### Directives to Support:
1. "solar_reduction": Usable solar drops. Required adjustment: {"hours": [int], "factor": float (0.0-1.0)}
2. "minimum_battery_reserve": Battery energy reserve floor. Required adjustment: {"hours": [int], "minimum_energy_kwh": float}
3. "no_charge_window": Battery charging prohibited. Required adjustment: {"hours": [int]}
4. "no_discharge_window": Battery discharging prohibited. Required adjustment: {"hours": [int]}
5. "max_grid_window": Grid import cap. Required adjustment: {"hours": [int], "max_grid_kwh": float}
6. "no_op": Note is irrelevant to today's 24-hour schedule. Required adjustment: null

### Rules:
- Output MUST be valid JSON following the schema below, and NOTHING else (no markdown fences, no prose).
- Convert time windows to 0-23 whole hours. Time windows are start-inclusive, end-exclusive
  (e.g. "1 PM to 3 PM" means hours [13, 14]).
- Sort hours in strictly ascending order with unique integers.
- Set applies = false ONLY for "no_op". For all other directives, set applies = true.
- Do NOT invent rules or params not explicitly stated. Do NOT alter demand, tariff, or battery
  parameters — only extract what Section 04 directive types allow.
- Every operator note must produce exactly one entry, in note_index order (0, 1, ... N-1).
- For solar_reduction, factor is the usable fraction that REMAINS (an 80% reduction -> factor 0.2).

### Response JSON Schema:
{
  "directive_interpretation": [
    {
      "note_index": int,
      "applies": bool,
      "directive_type": string,
      "structured_adjustment": object or null,
      "explanation": string
    }
  ]
}
"""


def _build_user_prompt(operator_notes: List[str]) -> str:
    numbered = "\n".join(f"{i}: {note}" for i, note in enumerate(operator_notes))
    return (
        "Interpret the following operator notes. Return ONE entry per note, "
        "in the exact JSON schema given in the system prompt, with no extra text.\n\n"
        f"Operator notes:\n{numbered}"
    )


def _extract_json(raw_text: str) -> Dict[str, Any]:
    """Strip markdown fences / stray text and parse JSON, defensively."""
    text = raw_text.strip()
    # Strip ```json ... ``` or ``` ... ``` fences if present
    fence_match = re.search(r"```(?:json)?\s*(\{.*\})\s*```", text, re.DOTALL)
    if fence_match:
        text = fence_match.group(1)
    else:
        # Fall back to grabbing the first {...} block
        brace_match = re.search(r"\{.*\}", text, re.DOTALL)
        if brace_match:
            text = brace_match.group(0)
    return json.loads(text)


class LLMInterpreterError(Exception):
    """Raised when the LLM call fails or returns unparseable output."""
    pass


def interpret_notes(operator_notes: List[str]) -> List[Dict[str, Any]]:
    """
    Calls Claude to interpret operator_notes and returns the raw
    (still UNTRUSTED / unvalidated) list of directive_interpretation dicts.
    """
    client = anthropic.Anthropic()  # reads ANTHROPIC_API_KEY from env

    try:
        response = client.messages.create(
            model=MODEL_NAME,
            max_tokens=2000,
            system=SYSTEM_PROMPT,
            messages=[{"role": "user", "content": _build_user_prompt(operator_notes)}],
        )
    except Exception as exc:  # network / auth / API errors
        raise LLMInterpreterError(f"LLM call failed: {exc}") from exc

    raw_text = "".join(
        block.text for block in response.content if getattr(block, "type", None) == "text"
    )

    try:
        parsed = _extract_json(raw_text)
        entries = parsed["directive_interpretation"]
        if not isinstance(entries, list):
            raise ValueError("directive_interpretation is not a list")
        return entries
    except Exception as exc:
        raise LLMInterpreterError(f"Could not parse LLM output as expected JSON: {exc}") from exc
