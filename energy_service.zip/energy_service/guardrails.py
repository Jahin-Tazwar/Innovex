"""
Deterministic guardrail validator (Section 08).

The LLM's raw output is treated as UNTRUSTED. This module checks every
entry against the fixed rules before anything is handed to the optimizer.
Invalid / malformed entries are coerced to a safe no_op rather than
crashing the service (Section 08: "SAFE FAILURE").
"""
from typing import List, Dict, Any

ALLOWED_TYPES = {
    "solar_reduction",
    "minimum_battery_reserve",
    "no_charge_window",
    "no_discharge_window",
    "max_grid_window",
    "no_op",
}


def _safe_no_op(note_index: int, reason: str) -> Dict[str, Any]:
    return {
        "note_index": note_index,
        "applies": False,
        "directive_type": "no_op",
        "structured_adjustment": None,
        "explanation": f"Safe fallback to no_op: {reason}",
    }


def _valid_hours(hours: Any) -> bool:
    if not isinstance(hours, list) or len(hours) == 0:
        return False
    if not all(isinstance(h, int) and not isinstance(h, bool) for h in hours):
        return False
    if any(h < 0 or h > 23 for h in hours):
        return False
    if len(set(hours)) != len(hours):
        return False
    if hours != sorted(hours):
        return False
    return True


def _validate_adjustment(directive_type: str, adj: Any, battery_capacity_kwh: float) -> bool:
    if directive_type == "no_op":
        return adj is None

    if not isinstance(adj, dict):
        return False
    if not _valid_hours(adj.get("hours")):
        return False

    if directive_type == "solar_reduction":
        factor = adj.get("factor")
        return isinstance(factor, (int, float)) and 0.0 <= float(factor) <= 1.0

    if directive_type == "minimum_battery_reserve":
        val = adj.get("minimum_energy_kwh")
        return (
            isinstance(val, (int, float))
            and val >= 0
            and val <= battery_capacity_kwh
        )

    if directive_type == "no_charge_window":
        return set(adj.keys()) <= {"hours"}

    if directive_type == "no_discharge_window":
        return set(adj.keys()) <= {"hours"}

    if directive_type == "max_grid_window":
        val = adj.get("max_grid_kwh")
        return isinstance(val, (int, float)) and val >= 0

    return False


def validate_interpretation(
    raw_entries: List[Dict[str, Any]],
    num_notes: int,
    battery_capacity_kwh: float,
) -> List[Dict[str, Any]]:
    """
    Validates and repairs the LLM's raw directive_interpretation list.
    Guarantees: exactly one entry per note_index in [0, num_notes-1], in order,
    each entry structurally sound and safe to feed to the optimizer.
    """
    by_index: Dict[int, Dict[str, Any]] = {}

    for entry in raw_entries:
        if not isinstance(entry, dict):
            continue
        idx = entry.get("note_index")
        if not isinstance(idx, int) or idx in by_index or not (0 <= idx < num_notes):
            continue

        directive_type = entry.get("directive_type")
        applies = entry.get("applies")
        adjustment = entry.get("structured_adjustment")
        explanation = entry.get("explanation", "")

        if directive_type not in ALLOWED_TYPES:
            by_index[idx] = _safe_no_op(idx, "unsupported or missing directive_type")
            continue

        if directive_type == "no_op":
            by_index[idx] = {
                "note_index": idx,
                "applies": False,
                "directive_type": "no_op",
                "structured_adjustment": None,
                "explanation": explanation or "Note does not affect the schedule.",
            }
            continue

        if applies is not True:
            by_index[idx] = _safe_no_op(idx, "applies flag missing/false for a non-no_op directive")
            continue

        if not _validate_adjustment(directive_type, adjustment, battery_capacity_kwh):
            by_index[idx] = _safe_no_op(idx, f"malformed structured_adjustment for {directive_type}")
            continue

        by_index[idx] = {
            "note_index": idx,
            "applies": True,
            "directive_type": directive_type,
            "structured_adjustment": adjustment,
            "explanation": explanation or f"{directive_type} directive applied.",
        }

    # Fill in any missing note indices (LLM dropped a note) with safe no_op
    result = []
    for idx in range(num_notes):
        if idx in by_index:
            result.append(by_index[idx])
        else:
            result.append(_safe_no_op(idx, "no interpretation returned by LLM for this note"))

    return result
