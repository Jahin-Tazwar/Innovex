"""
Offline test: simulates a raw LLM output (as if Claude had returned it)
and runs it through guardrails -> optimizer, without needing a live API key.
Mirrors the example from Section 07.4 of the problem statement.
"""
from guardrails import validate_interpretation
from optimizer import solve_schedule, InfeasibleScenarioError

# 24-hour scenario: flat demand, some solar midday, cheap tariff at night
hours_data = []
for h in range(24):
    demand = 150 if 0 <= h < 6 else (250 if 8 <= h < 20 else 180)
    solar = 0
    if 6 <= h < 18:
        # simple solar bell curve
        solar = max(0, 300 - abs(h - 12) * 45)
    tariff = 5 if (0 <= h < 6 or h >= 22) else (12 if 17 <= h < 21 else 8)
    hours_data.append({"hour": h, "demand_kwh": demand, "solar_kwh": solar, "tariff_bdt_per_kwh": tariff})

battery = {
    "capacity_kwh": 500,
    "initial_energy_kwh": 200,
    "minimum_energy_kwh": 50,
    "max_charge_kwh_per_hour": 100,
    "max_discharge_kwh_per_hour": 100,
}

operator_notes = [
    "Solar output will drop to about 20% from 1 PM to 3 PM.",
    "Do not charge the battery between 2 PM and 4 PM.",
    "The cafeteria menu changes tomorrow.",
]

# Simulated raw LLM output (what we expect Claude to return for these notes)
simulated_llm_output = [
    {
        "note_index": 0,
        "applies": True,
        "directive_type": "solar_reduction",
        "structured_adjustment": {"hours": [13, 14], "factor": 0.2},
        "explanation": "Solar drops to 20% between 1-3 PM.",
    },
    {
        "note_index": 1,
        "applies": True,
        "directive_type": "no_charge_window",
        "structured_adjustment": {"hours": [14, 15]},
        "explanation": "No charging allowed 2-4 PM.",
    },
    {
        "note_index": 2,
        "applies": False,
        "directive_type": "no_op",
        "structured_adjustment": None,
        "explanation": "Cafeteria menu is irrelevant to energy scheduling.",
    },
]

directives = validate_interpretation(
    simulated_llm_output, num_notes=len(operator_notes), battery_capacity_kwh=battery["capacity_kwh"]
)
print("=== Validated directives ===")
for d in directives:
    print(d)

try:
    result = solve_schedule(hours_data, battery, directives)
except InfeasibleScenarioError as e:
    print("INFEASIBLE:", e)
    raise SystemExit(1)

print("\n=== Result ===")
print("total_grid_kwh:", result["total_grid_kwh"])
print("total_cost_bdt:", result["total_cost_bdt"])
print("peak_grid_kwh:", result["peak_grid_kwh"])

print("\n=== Hourly plan ===")
for e in result["hourly_plan"]:
    print(e)

# --- sanity checks mirroring judge validation (Section 11.3) ---
assert len(result["hourly_plan"]) == 24
final_energy = result["hourly_plan"][-1]["battery_energy_after_kwh"]
assert abs(final_energy - battery["initial_energy_kwh"]) < 0.01, f"battery neutrality failed: {final_energy}"

# no-charge-window check for hours 14,15
for e in result["hourly_plan"]:
    if e["hour"] in (14, 15):
        assert e["battery_action"] != "charge", f"charging happened in no-charge hour {e['hour']}"

# energy balance check
for h in range(24):
    e = result["hourly_plan"][h]
    charge = e["battery_kwh"] if e["battery_action"] == "charge" else 0
    discharge = e["battery_kwh"] if e["battery_action"] == "discharge" else 0
    lhs = e["grid_kwh"] + e["solar_used_kwh"] + discharge
    rhs = hours_data[h]["demand_kwh"] + charge
    assert abs(lhs - rhs) < 0.01, f"energy balance failed at hour {h}: {lhs} vs {rhs}"

print("\nALL SANITY CHECKS PASSED")
