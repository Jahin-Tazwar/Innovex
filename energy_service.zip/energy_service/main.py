"""
Smart Campus Energy Optimization API.

Flow (per Section 03):
  Energy Data + Operator Notes -> LLM Interpreter -> Guardrail Validator
  -> Math Optimizer -> Final Validator -> API Response
"""
import logging
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from models import OptimizeRequest, OptimizeResponse
from llm_interpreter import interpret_notes, LLMInterpreterError
from guardrails import validate_interpretation
from optimizer import solve_schedule, InfeasibleScenarioError

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("energy_service")

app = FastAPI(title="Smart Campus Energy Optimization API")


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/optimize-energy")
def optimize_energy(payload: OptimizeRequest):
    try:
        hours_data = [h.model_dump() for h in payload.hours]
        hours_data.sort(key=lambda h: h["hour"])
        battery = payload.battery.model_dump()

        # 1. LLM Interpreter (untrusted output)
        try:
            raw_entries = interpret_notes(payload.operator_notes)
        except LLMInterpreterError as exc:
            logger.warning("LLM interpretation failed, falling back to all no_op: %s", exc)
            raw_entries = []

        # 2. Guardrail Validator (deterministic, safe-failure)
        directives = validate_interpretation(
            raw_entries,
            num_notes=len(payload.operator_notes),
            battery_capacity_kwh=battery["capacity_kwh"],
        )

        # 3. Math Optimizer
        result = solve_schedule(hours_data, battery, directives)

        # 4. Build response
        applied_types = sorted(
            {d["directive_type"] for d in directives if d["applies"]}
        )
        if applied_types:
            summary = (
                f"Optimized 24-hour schedule minimizing grid cost while applying: "
                f"{', '.join(applied_types)}. Total grid cost: "
                f"{result['total_cost_bdt']:.2f} BDT."
            )
        else:
            summary = (
                f"Optimized 24-hour schedule minimizing grid cost with no active "
                f"operator directives. Total grid cost: {result['total_cost_bdt']:.2f} BDT."
            )

        response = OptimizeResponse(
            scenario_id=payload.scenario_id,
            directive_interpretation=directives,
            hourly_plan=result["hourly_plan"],
            total_grid_kwh=result["total_grid_kwh"],
            total_cost_bdt=result["total_cost_bdt"],
            peak_grid_kwh=result["peak_grid_kwh"],
            plan_summary=summary,
        )
        return response

    except InfeasibleScenarioError as exc:
        return JSONResponse(status_code=422, content={"error": str(exc)})
    except Exception as exc:
        logger.exception("Unhandled error in /optimize-energy")
        return JSONResponse(status_code=500, content={"error": "Internal server error"})


@app.exception_handler(Exception)
async def generic_exception_handler(request: Request, exc: Exception):
    logger.exception("Unhandled exception")
    return JSONResponse(status_code=500, content={"error": "Internal server error"})
